//
//  TableViewController.swift
//  project_ca
//
//  Created by Student on 05/11/23.
//  Copyright © 2023 Student. All rights reserved.
//

import UIKit


class TableViewController: UIViewController ,UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet weak var tableview: UITableView!
//    var category : [String] = ["Income Tax Slab for People less than 60",
//                               "Income Tax Slab for People Between 60 to 80 Years",
//                               "Income Tax Slab for People More than 80 Years "]
//    var lessthan : [String] = [""]
    var incomeTaxData: [(rate: Double, slab: String)] = [
        (0, "Rs. 3 lakhs"),
        (5, "Rs. 3 lakhs - Rs. 5 lakhs"),
        (20, "Rs. 5 lakhs - Rs. 10 lakhs"),
        (30, "Rs. 10 lakhs and more")]
//    let incomeTaxData = [["slab": "Rs. 3 lakhs", "rate": "NIL"],
//                         ["slab": "Rs. 3 lakhs - Rs. 5 lakhs", "rate": "5.00%"],
//                         ["slab": "Rs. 5 lakhs - Rs. 10 lakhs", "rate": "20.00%"],
//                         ["slab": "Rs. 10 lakhs and more", "rate": "30.00%"]]
//  
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return incomeTaxData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let slab = incomeTaxData[indexPath.row]
        cell.textLabel?.text = slab.slab
        cell.detailTextLabel?.text = String(format: "%.2f%%", slab.rate)
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableview.dataSource = self
        tableview.delegate = self
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
